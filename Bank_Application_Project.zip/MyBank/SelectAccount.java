package com.MyBank;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class SelectAccount {
	
	Menu me = new Menu();
	Scanner in = new Scanner(System.in);
	public int selectAccount() {
		
		String DbCheck = "select * from Bank";
		int count=0;
		int account = 0;
		try {
			
			
			
			me.preparedStatement = me.conn.prepareStatement(DbCheck);
			ResultSet rs = me.preparedStatement.executeQuery(DbCheck);
			while(rs.next())
			{
				count++;
			}
			
			 if(count == 0 ) {
			 System.out.println("No customers at your bank"); 
			 return -1; 
			 }
			 ResultSet rs1 = me.preparedStatement.executeQuery(DbCheck);
			System.out.println("+-----------------------------------------------------------------------------------------------+");
			System.out.println("|---------------------------------------List  of  account---------------------------------------|");
			System.out.println("|                                                                                               |");
			while(rs1.next())
			{
				int id = rs1.getInt("Id");
				int AN = rs1.getInt("AccountNumber");
				String fn = rs1.getString("FirstName");
				String ln = rs1.getString("LastName");
				
				System.out.println("   "+ id+" )"+" AccountNumber: "+AN+"  FirstName: "+fn+"  LastName: "+ln);

			}
			System.out.println("|                                                                                               |");
			System.out.println("|                                                                                               |");
			System.out.println("+-----------------------------------------------------------------------------------------------+");
			if(me.selection==1)
			{
			System.out.println("Please Enter serial number from above list of account to make a Deposit to a specific Account: ");
			}
			else if(me.selection==2)
			{
				System.out.println("Please Enter serial number from above list of account to make a Withdrawl from a specific Account: ");
			}
			else if(me.selection==3)
			{
				System.out.println("Please Enter serial number from above list of account to check Balance of that specific Account: ");
			}
			
			try {
				account = Integer.parseInt(in.nextLine());
				
			} 
			catch (NumberFormatException e) 
			{
				account = -1;
			}
			
			if(account < 0 || account > count)
			{
				System.out.println("Invalid Account Selected");
				account = -1;
			}
			me.preparedStatement.close();
			
			
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		
		return account;
		
		
		
	}
}
