package com.MyBank;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class CreateAAccount {
	String firstName, lastName,accountType = "";
	double initialDeposit = 0;
	boolean valid = false;
	Scanner in = new Scanner(System.in);
	Menu me = new Menu();
	String insert = "Insert into Bank (AccountNumber, FirstName, LastName, AccountType, Balance) values (?,?,?,?,?)";
	String ct = "select * from Bank";
	int count=0;
	static int numberOfAccount = 100000;
	public void createAnAccount() {
		
		while(!valid)
		{
			System.out.println("Please Enter Account Type (Current/Savings): ");
			accountType = in.nextLine();
			if(accountType.equalsIgnoreCase("current")||accountType.equalsIgnoreCase("savings"))
			{
				valid = true;
			}
			else
			{
				System.out.println("Invalid Selection...Please enter current or savings..");
			}
		}
		
		
		
		System.out.print("Enter Your First Name: ");
		firstName = in.nextLine();
		
		System.out.print("Enter Your Last Name: ");
		lastName = in.nextLine();
		
		valid = false;
		while(!valid)
		{
			System.out.println("Please Enter initial Deposite: ");
			try {
					
				initialDeposit = Double.parseDouble(in.nextLine()); 
				
			} 
			catch (NumberFormatException e) 
			{
				System.out.println("Initial Deposite Must be a Number...");
			}
			
			if(accountType.equalsIgnoreCase("current"))
			{
				if(initialDeposit<500)
				{
					System.out.println("Current Account requires a minimum amount of Rs 500");
				}
				else
				{
					valid = true;
				}
			}
			else if(accountType.equalsIgnoreCase("savings"))
			{
				if(initialDeposit<100)
				{
					System.out.println("Savings Account requires a minimum amount of Rs 100");
				}
				else
				{
					valid = true;
				}
			}
		}
		
		
		try
		{
			
			me.preparedStatement = me.conn.prepareStatement(ct);
			ResultSet rs = me.preparedStatement.executeQuery(ct);
			while(rs.next())
			{
				count++;
			}
			if(count==0) {
				me.preparedStatement = me.conn.prepareStatement(insert);
				me.preparedStatement.setInt(1, numberOfAccount++);
				me.preparedStatement.setString(2, firstName);
				me.preparedStatement.setString(3, lastName);
				me.preparedStatement.setString(4, accountType);
				me.preparedStatement.setDouble(5, initialDeposit);
				me.preparedStatement.executeUpdate();
			}
			else
			{
				String stm = "select * from Bank where Id = "+count;
				int accountnm=0;
				me.preparedStatement = me.conn.prepareStatement(stm);
				ResultSet rs1 = me.preparedStatement.executeQuery(stm);
				while(rs1.next())
				{
					accountnm = rs1.getInt("AccountNumber");
					System.out.println(accountnm);
				}
				
				me.preparedStatement = me.conn.prepareStatement(insert);
				me.preparedStatement.setInt(1, ++accountnm);
				me.preparedStatement.setString(2, firstName);
				me.preparedStatement.setString(3, lastName);
				me.preparedStatement.setString(4, accountType);
				me.preparedStatement.setDouble(5, initialDeposit);
				me.preparedStatement.executeUpdate();
			}
			me.preparedStatement.close();
			
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		
	}
}
