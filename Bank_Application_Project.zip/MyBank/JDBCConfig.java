package com.MyBank;

import java.sql.Connection;
import java.sql.DriverManager;

public class JDBCConfig {
	
	private static final String DB_Driver = "com.mysql.jdbc.Driver";
	private static final String DB_URL = "jdbc:mysql://localhost:3306/";
	private static final String DB_Name = "bankapplication";
	private static final String DB_UserName = "root";
	private static final String DB_Password = "rspl123#";
	
	public static Connection getConnection() {
		
		Connection conn = null;
		try {
				
				Class.forName(DB_Driver);
				
				conn = DriverManager.getConnection(DB_URL+DB_Name,DB_UserName,DB_Password);
				
				if(conn!=null) {
					System.out.println("Successufully Connected...");
				}else {
					System.out.println("Failed to connect");
				}
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return conn;
	}
}
