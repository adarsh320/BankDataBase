package com.MyBank;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;


public class Menu {
	Scanner in = new Scanner(System.in);
   // Bank bank = new Bank();
    boolean exit;
    static int numberOfAccount = 100000;
    //Database
    static int selection;
    static Connection conn = null;
    public PreparedStatement preparedStatement = null;
	String insert = "Insert into Bank (AccountNumber, FirstName, LastName, AccountType, Balance) values (?,?,?,?,?)";
	public static void main(String[] args) {
		
	    try { 
	    	conn =JDBCConfig.getConnection();
	    	Menu menu = new Menu();
	        menu.runMenu();
	        conn.close();
	       
	    }catch (Exception e) {
			e.printStackTrace();
		}
		
       
	}
	
	public void runMenu()
    {
        printTitle();
        while(!exit)
        {
            printMenu();
            int choice = getInput();
            performAction(choice);
        }
    }

    private void printTitle() {
        System.out.println("+--------------------------------------+");
        System.out.println("|                                      |");
        System.out.println("|        Welcome to Peace Bank         |");
        System.out.println("|                                      |");
        System.out.println("+--------------------------------------+");
    }

    private void printMenu() {
    	System.out.println("+--------------------------------------+");
        System.out.println("| 1) Create a New Account              |");
        System.out.println("| 2) Make a Deposit                    |");
        System.out.println("| 3) Make a Withdrwal                  |");
        System.out.println("| 4) Check Account Details and Balance |");
        System.out.println("| 0) Exit                              |");
        System.out.println("+--------------------------------------+");
    }

    private int getInput() {
        int choice = -1;
        do{
            System.out.println("Enter Your Choice: ");
            try
            {
                choice = Integer.parseInt(in.nextLine());
            }
            catch (NumberFormatException e) 
            {
                System.out.println("Invalid Selection...Numbers only please...");
            }
            if(choice<0 || choice>4)
            {
                System.out.println("Choice is outside range...");
            }
        }while(choice<0 || choice>4);
        return choice;
    }

    private void performAction(int choice) {
        switch(choice)
        {
            case 0:System.out.println("Thankyou For using our application...");
                   System.exit(0);
                   break;
            case 1: CreateAAccount c = new CreateAAccount();
            		c.createAnAccount();
                    break;
                    
            case 2: MakeADeposit m = new MakeADeposit();
            		m.makeADeposit();
                    break;
                    
            case 3:MakeAWithdrawl mw = new MakeAWithdrawl(); 
            		mw.makeAWithdrawl();
                    break;
                    
            case 4: CheckAccountDetails cal = new CheckAccountDetails();
            		cal.listBalance();
                    break;
            default:
            		System.out.println("Unknown Error has occured");
                
        }
    }
    
}  
	