package com.MyBank;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class MakeADeposit {
	Scanner in = new Scanner(System.in);
	Menu me = new Menu();
	SelectAccount sl = new SelectAccount();
	public void makeADeposit() {
		
		
    	me.selection =1;
		int account = sl.selectAccount();
		me.selection =0;
		if(account>=0) {
			String DbCheck = "select * from Bank where Id ="+account;
			try
			{
				
				
				me.preparedStatement = me.conn.prepareStatement(DbCheck);
				//preparedStatement.setInt(1, account);
				ResultSet rs = me.preparedStatement.executeQuery(DbCheck);
				while(rs.next())
				{
					
					int AN = rs.getInt("AccountNumber");
					String AT = rs.getString("AccountType");
					double bal = rs.getDouble("Balance");
					System.out.println(" AccountNumber: "+AN+" \n AccountType: "+AT+"  \n Balance: "+bal);
					System.out.println("Enter Amount you want to deposite: ");
					double amount = 0;
					try {
						amount = Double.parseDouble(in.nextLine());
						
					} 
					catch (NumberFormatException e) 
					{
						amount = 0;
					}
					
					if(amount <= 0) 
					{
					     System.out.println("You Cannot enter Negative amount..");
					     return;
					}
					 		
					 String update = "UPDATE Bank SET Balance = ? WHERE Id = ?";		
					 me.preparedStatement = me.conn.prepareStatement(update);
					 me.preparedStatement.setDouble(1, (rs.getDouble("Balance") + amount));
					 me.preparedStatement.setInt(2, account);
					 me.preparedStatement.executeUpdate();
					 me.preparedStatement = me.conn.prepareStatement(DbCheck);
					 rs = me.preparedStatement.executeQuery(DbCheck);
					 while(rs.next()) {
					 System.out.println("+------------------------------------------------------------------------+");
					 System.out.println("|                                                                        |");
					 System.out.println("   You have Deposit Rs: "+amount+"                                      ");
					 System.out.println("   Now your new balance is Rs: "+rs.getDouble("Balance")+"                ");
					 System.out.println("|                                                                        |");
					 System.out.println("+------------------------------------------------------------------------+");
					}
				}
				me.preparedStatement.close();
				
			}
			catch (Exception e) 
			{
				e.printStackTrace();
			}
		
		
		}
	}

}
