package com.MyBank;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class CheckAccountDetails {
	Scanner in = new Scanner(System.in);
	Menu me = new Menu();
	SelectAccount sl = new SelectAccount();
	public void listBalance() {
		me.selection =3;
		int account = sl.selectAccount();
		me.selection =0;
		if(account>=0) {
		
			
			String DbCheck = "select * from Bank where Id ="+account;
			try
			{
				
				me.preparedStatement = me.conn.prepareStatement(DbCheck);
				ResultSet rs = me.preparedStatement.executeQuery(DbCheck);
				while(rs.next() && (rs.getInt("Id")==account))
				{
					
					int AN = rs.getInt("AccountNumber");
					String AT = rs.getString("AccountType");
					double bal = rs.getDouble("Balance");
					System.out.println(" AccountNumber: "+AN+" \n AccountType: "+AT+"  \n Balance: "+bal);

				}
				me.preparedStatement.close();
				
			}
			catch (Exception e) 
			{
				e.printStackTrace();
			}
		}
		
	}

}
